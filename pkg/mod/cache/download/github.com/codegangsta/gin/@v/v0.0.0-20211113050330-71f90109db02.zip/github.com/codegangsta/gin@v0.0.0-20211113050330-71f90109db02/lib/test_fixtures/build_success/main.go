package main

func main() {
	println("Good to go")
}
